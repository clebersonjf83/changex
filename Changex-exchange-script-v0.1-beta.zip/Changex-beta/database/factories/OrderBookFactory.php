<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\OrderBook;
use Faker\Generator as Faker;

$factory->define(OrderBook::class, function (Faker $faker) {
    return [
        //
    ];
});
