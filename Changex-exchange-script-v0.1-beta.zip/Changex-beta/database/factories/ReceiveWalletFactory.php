<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\ReceiveWallet;
use Faker\Generator as Faker;

$factory->define(ReceiveWallet::class, function (Faker $faker) {
    return [
        //
    ];
});
