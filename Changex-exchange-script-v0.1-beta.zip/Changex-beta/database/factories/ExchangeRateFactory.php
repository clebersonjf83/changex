<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model;
use Faker\Generator as Faker;

$factory->define(Model::class, function (Faker $faker) {
    $default_currencies = [
        ['currency_name' => 'Bitcoin', 'currency_symbol' => 'BTC'],
        ['currency_name' => 'Ethereum', 'currency_symbol' => 'ETH'],
        ['currency_name' => 'Ripple', 'currency_symbol' => 'XRP'],
        ['currency_name' => 'Bitcoin Cash', 'currency_symbol' => 'BCH'],
        ['currency_name' => 'Litecoin', 'currency_symbol' => 'LTC'],
        ['currency_name' => 'Binance coin', 'currency_symbol' => 'BNB'],
        ['currency_name' => 'EOS', 'currency_symbol' => 'EOS'],
        ['currency_name' => 'Bitcoin SV', 'currency_symbol' => 'BSV'],
        ['currency_name' => 'Monero', 'currency_symbol' => 'XMR'],
        ['currency_name' => 'Stellar', 'currency_symbol' => 'XLM'],
        ['currency_name' => 'Cardano', 'currency_symbol' => 'ADA'],
        ['currency_name' => 'Tron', 'currency_symbol' => 'TRX'],
        ['currency_name' => 'Dash', 'currency_symbol' => 'Dash'],
        ['currency_name' => 'Tezos', 'currency_symbol' => 'XTZ'],
        ['currency_name' => 'NEO', 'currency_symbol' => 'NEO'],
        ['currency_name' => 'IOTA', 'currency_symbol' => 'MIOTA'],
        ['currency_name' => 'Cosmos', 'currency_symbol' => 'ATOM'],
        ['currency_name' => 'Ethereum classic', 'currency_symbol' => 'ETC'],
        ['currency_name' => 'NEM', 'currency_symbol' => 'XEM'],
        ['currency_name' => 'Ontology', 'currency_symbol' => 'ONT'],
        ['currency_name' => 'Zcash', 'currency_symbol' => 'ZEC'],
        ['currency_name' => 'Dogecoin', 'currency_symbol' => 'DOGE'],
        ['currency_name' => 'VeChain', 'currency_symbol' => 'VET'],
        ['currency_name' => 'Decred', 'currency_symbol' => 'DCR'],
        ['currency_name' => 'Bitcoin gold', 'currency_symbol' => 'BTG'],
        ['currency_name' => 'Qtum', 'currency_symbol' => 'QTUM'],
        ['currency_name' => 'Ravencoin', 'currency_symbol' => 'RVN'],
        ['currency_name' => 'Lisk', 'currency_symbol' => 'LSK'],
        ['currency_name' => 'Nano', 'currency_symbol' => 'NANO'],
        ['currency_name' => 'Bitcoin Diamond', 'currency_symbol' => 'BCD'],
        ['currency_name' => 'Energi', 'currency_symbol' => 'NRG'],
        ['currency_name' => 'Waves', 'currency_symbol' => 'WAVES'],
        ['currency_name' => 'Bytecoin', 'currency_symbol' => 'BCN'],
        ['currency_name' => 'DigiByte', 'currency_symbol' => 'DGB'],
        ['currency_name' => 'BitShares', 'currency_symbol' => 'BTS'],
        ['currency_name' => 'MonaCoin', 'currency_symbol' => 'MONA'],
        ['currency_name' => 'Theta', 'currency_symbol' => 'THETA'],
        ['currency_name' => 'Byta', 'currency_symbol' => 'BTM'],
        ['currency_name' => 'Icon', 'currency_symbol' => 'ICX'],
        ['currency_name' => 'Komodo', 'currency_symbol' => 'KMD'],
        ['currency_name' => 'HyperCash', 'currency_symbol' => 'HC'],
        ['currency_name' => 'GXChain', 'currency_symbol' => 'GXC'],
        ['currency_name' => 'Verge', 'currency_symbol' => 'XVG'],
        ['currency_name' => 'Abbc coin', 'currency_symbol' => 'ABBC'],
        ['currency_name' => 'Zilliqa', 'currency_symbol' => 'ZIL'],
        ['currency_name' => 'Aeternity', 'currency_symbol' => 'AE'],
        ['currency_name' => 'Steem', 'currency_symbol' => 'STEEM'],
        ['currency_name' => 'Zcoin', 'currency_symbol' => 'XZC'],
        ['currency_name' => 'Electroneum', 'currency_symbol' => 'ETN'],
        ['currency_name' => 'Stratis', 'currency_symbol' => 'STRAT'],
        ['currency_name' => 'Horizen', 'currency_symbol' => 'ZEN'],
        ['currency_name' => 'ReddCoin', 'currency_symbol' => 'RDD'],
        ['currency_name' => 'Beam', 'currency_symbol' => 'BEAM'],
        ['currency_name' => 'Factom', 'currency_symbol' => 'FCT'],
        ['currency_name' => 'Newton', 'currency_symbol' => 'NEW'],
        ['currency_name' => 'IPChain', 'currency_symbol' => 'IPC'],
        ['currency_name' => 'Truechain', 'currency_symbol' => 'TRUE'],
        ['currency_name' => 'Ark', 'currency_symbol' => 'ARK'],
        ['currency_name' => 'Aion', 'currency_symbol' => 'AION'],
        ['currency_name' => 'Vertcoin', 'currency_symbol' => 'VTC'],
        ['currency_name' => 'Nexus', 'currency_symbol' => 'NXS']
    ];
    return [
        //
    ];
});
