/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

require('./bootstrap');

// import modules
import MainViews from './components/MainViews'
import router from './Router/Router'
import store from './Store/index'

window.Vue = require('vue')

import Toastr from 'vue-toastr'
require('vue-toastr/src/vue-toastr.scss')
Vue.use(Toastr, { 
    defaultTimeout: 5000,
    defaultProgressBar: false,
    defaultProgressBarValue: 0,
    defaultType: "error",
    defaultPosition: "toast-top-right",
    defaultCloseOnHover: false,
 });

import Clipboard from 'v-clipboard' 
Vue.use(Clipboard);

import VueNumerals from 'vue-numerals'
Vue.use(VueNumerals)

import User from './Helpers/UserAuth'
window.User = User

const app = new Vue({
    el: '#app',
    router,
    store,
    render: h => h(MainViews)
});
