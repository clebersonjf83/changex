/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

// import components


const routes = [
    
    // routes
    
]

const router = new VueRouter({
    routes,
    hashbang: false,
    mode: 'history'
})


const DEFAULT_TITLE = 'Welcome to Changex trading platform';
router.beforeEach((to, from, next) => {
    document.title = to.meta.title || DEFAULT_TITLE
    if (to.matched.some(record => record.meta.requiresAuth))
    {
        // check if user is loggedin and go to the next request
    }else {
        next()
        window.scrollTo(0, 0)
    }
})


export default router