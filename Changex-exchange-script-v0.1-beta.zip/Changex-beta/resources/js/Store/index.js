/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */
 
import Vue from 'vue'
import Vuex from 'vuex'

// import store modules
import AuthStore from './AuthStore'
import ExchangeStore from './ExchangeStore'

Vue.use(Vuex)

export default new Vuex.Store({
    namespaced: true,
    modules: {
        AuthStore,
        ExchangeStore,
    }
})