<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, minimal-ui">
        <meta name="keywords" content="cryptocurrency trading script, cryptocurrency exchange software, bitcoin investment, cryptocurrency market, crypto exchange software, open source bitcoin trading platform">
        <meta name="description" content="Welcome to the world's first affordable currency trading platform demo, feel free to drop us a mail or chat with us.">
        <meta name="author" content="opensoftweb.com, opensoftweb@gmail.com">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
        <link rel="stylesheet" href="{{ asset('css/app.css') }}">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>{{ config('app.name') }}</title>
    </head>
    <body>
        <!--
         *  This file is part of changex-exchange
         * ---------------------------------------------------------------
         *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
         * ---------------------------------------------------------------
         *  URL <opensoftweb.com> for live demo
         * ---------------------------------------------------------------
         *  Built with Love
         -->
        <div id="app">
        </div>
        <script src="{{ asset('js/app.js') }}"></script>
    </body>
</html>