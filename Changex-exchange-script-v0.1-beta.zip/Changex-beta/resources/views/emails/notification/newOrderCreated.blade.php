@component('mail::message')
# Your order is pending deposit 

Please send deposit to proceed with this order. <br>
**Order Id**: {{ $order->trxID }} <br>
**Amount**: {{ $order->amount }} <br>
**Currency pair**: **{{ $order->from_currency }}** to **{{ $order->to_currency }}** <br>
**{{ $order->from_currency }} Address**: {{ $order->exchange_wallet }} <br>
**Receipient**: {{ $order->receipient_wallet }} <br><br>

If you have any troubles or concern with this order, please contact us immediately.

@component('mail::button', ['url' => $check_order_status])
Check status
@endcomponent

Thank you,<br>
{{ config('app.name') }} Team
@endcomponent
