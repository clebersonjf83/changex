@component('mail::message')
# Congratulations Order completed!

Hello, <br>
Your exchange order with order id **{{ $orderId }}** has been completed, thank you for trusting us, we do love to continue doing business with you.

Thank You,<br>
{{ config('app.name') }} Team
@endcomponent
