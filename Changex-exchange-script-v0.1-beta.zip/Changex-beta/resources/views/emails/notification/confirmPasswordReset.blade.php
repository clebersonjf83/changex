@component('mail::message')
# Confirm Password Reset

Hello, <br>
You have just initiated a request to reset the password in {{ config('app.name') }}'s account linked to your email **{{ $account->email }}**. To set a new password, please click the button below:

@component('mail::button', ['url' => $reset_url])
Reset Password
@endcomponent

For security reasons, this link will expire in 30 minutes.
If you did not make this password reset request, contact us immediately. {{ config('app.url') }}.

Best regards,<br>
{{ config('app.name') }} Team
@endcomponent
