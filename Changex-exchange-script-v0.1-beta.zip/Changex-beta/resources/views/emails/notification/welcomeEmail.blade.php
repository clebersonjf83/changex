@component('mail::message')
# Welcome to {{ config('app.name') }}!

{{ config('app.name') }} is a cryptocurrency exchange with the best exchange rates and first class customer support 24/7.
Your exchange has never been so supportive and fast.

@component('mail::panel')
Your Login details are shown below, feel free to change your default password!<br> <br>
**Email**: {{ $user_email }} <br>
**Password**: {{ $user_password }}

@component('mail::button', ['url' => $login_url])
Login
@endcomponent
@endcomponent

Best regards,<br>
{{ config('app.name') }} Team
@endcomponent
