<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

/**
 * Resolve IP, device info, browser and log user activities
 */
trait ResolveIP
{
    public function resolveIP(Request $request) : array
    {
        
    }
}
