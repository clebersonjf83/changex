<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

namespace App\Http\Traits;

use Symfony\Component\HttpFoundation\Response;

/**
 * This takes care of all wallet and blockchain processing
 */
trait ProcessPayment
{
    

}
