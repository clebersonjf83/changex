<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\ResourceCollection;

class OrderBookCollection extends ResourceCollection
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'data' => /* data */,
            'meta' => [
                
            ]
        ];
    }
}
