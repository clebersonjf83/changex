<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

namespace App\Http\Middleware;

use Closure;
use Tymon\JWTAuth\Facades\JWTAuth;

class requireAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        JWTAuth::parseToken()->authenticate();
        return $next($request);
    }
}
