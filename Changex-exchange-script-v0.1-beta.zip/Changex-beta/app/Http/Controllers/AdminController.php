<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for working demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

namespace App\Http\Controllers;

use App\User;
use App\Model\OrderBook;
use App\Model\Application;
use App\Model\ExchangeRate;
use App\Model\WalletBalance;
use Illuminate\Http\Request;
use App\Model\ExchangeSetting;
use App\Model\SupportedCountry;
use App\Http\Resources\UserResource;
use App\Notifications\OrderCompleted;
use App\Services\CoreExchangeService;
use App\Http\Resources\UserCollection;
use App\Http\Resources\CountryResource;
use App\Http\Resources\OrderBookResource;
use App\Http\Resources\ApplicationResource;
use App\Http\Resources\OrderBookCollection;
use App\Http\Resources\WalletBalanceResource;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Resources\AllExchangeRatesResource;
use App\Http\Resources\ExchangeSettingsResource;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('requireAdmin');
    }

    /**
     * --------------------------------------------------
     *  Start User management Operations
     * --------------------------------------------------
     */

    public function getUsers()
    {
        
    }


    public function markOrderAsCompleted(OrderBook $trxId)
    {
        /**
         * @var integer $trxId['status']
         * 0-pending
         * 1-waiting for network confirmations
         * 2-order processing
         * 3-order completed
         * 4-order cancelled
         *
         **/
        
    }


    /**
     * -----------------------------------------------------
     *  Start Exchange management operations
     * -----------------------------------------------------
     */

    public function walletTransfer(Request $request)
    {

    }

    /**
     * ----------------------------------------------
     *  Start Exchange Rate Operations
     * ----------------------------------------------
     */

    public function resetExchangeRates()
    {
        
    }

    public function getAllCurrencies()
    {
        
    }

    public function updateSupportedCurrencies(ExchangeRate $currency)
    {
        
    }

    /**
     * -----------------------------------------------
     *  Start Supported countries operations
     * -----------------------------------------------
     */

    public function resetSupportedCountries(CoreExchangeService $coreExchangeService)
    {
        
    }

    public function updateSupportedCountries(SupportedCountry $supportedCountry)
    {
        
    }

    /**
     * -----------------------------------------------
     *  Start Exchange patnership operations
     * -----------------------------------------------
     */

    public function getApplications()
    {
        
    }


    /**
     * ----------------------------------------------------------------------------------
     *  For any suggestion, error or bug, please drop me a mail
     * ----------------------------------------------------------------------------------
     *  <opensoftweb@gmail.com> or <support@opensoftweb.com>
     * ----------------------------------------------------------------------------------
     *  Built with Love 
     * ----------------------------------------------------------------------------------
     */
}
