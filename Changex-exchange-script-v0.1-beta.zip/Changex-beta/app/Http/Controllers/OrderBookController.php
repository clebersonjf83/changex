<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for a live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

namespace App\Http\Controllers;

use App\User;
use App\Model\OrderBook;
use Illuminate\Http\Request;
use App\Http\Traits\ProcessPayment;
use App\Http\Requests\SaveOrderRequest;
use Symfony\Component\HttpFoundation\Response;

class OrderBookController extends Controller
{
    use ProcessPayment;
    
    public function __construct()
    {
        $this->middleware('requiresUser');
    }

    public function createNewOrder(SaveOrderRequest $request)
    {
    
    }

    public function getAllMyOrder()
    {
        
    }

    public function getSingleOrder(OrderBook $trxId)
    {
        
    }
}
