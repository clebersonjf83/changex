<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for a live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

namespace App\Http\Controllers;

use App\Model\UserBank;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Resources\UserBankResource;
use App\Http\Requests\UpdatePasswordRequest;
use Symfony\Component\HttpFoundation\Response;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('requiresUser');
    }

    public function updateUserPassword(UpdatePasswordRequest $request)
    {
        
    }

    public function getUserBankInfo()
    {
        
    }

    public function updateUserBankInfo(Request $request)
    {
        
    }
}
