<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for a live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

namespace App\Http\Controllers;

use App\User;
use Carbon\Carbon;
use App\PasswordRecovery;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Notifications\ConfirmPasswordReset;
use Symfony\Component\HttpFoundation\Response;

class PasswordRecoveryController extends Controller
{
    public function userExists($email)
    {
        
    }

    public function generateToken($prefix)
    {
        
    }

    public function passwordResetRequest(Request $request)
    {
    
    }

    public function confirmPasswordResetRequest(PasswordRecovery $token, Request $request)
    {
        
    }
}
