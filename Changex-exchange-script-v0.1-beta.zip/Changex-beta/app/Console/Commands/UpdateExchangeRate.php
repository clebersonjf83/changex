<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\CoreExchangeService;

class UpdateExchangeRate extends Command
{

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'changex:update-exchange-rate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update the exchange rates every hour of the day and log 24 hours change.';

    private $coreExchangeService;
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(CoreExchangeService $coreExchangeService)
    {
        parent::__construct();
        $this->coreExchangeService = $coreExchangeService;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->info('Please hold on, we are updating all exchange rate...');
        $this->coreExchangeService->resetExchangeRates();
        $this->info('Thank you for your patience, Update successful');
    }
}
