<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/**
 * ------------------------------------------------------------------------
 *  Public route for authentications
 * ------------------------------------------------------------------------
 */

Route::group([

    'middleware' => 'api',
    'prefix' => 'auth'

], function ($router) {

    /*
        User authentication routes
    */
});


/**
 * -----------------------------------------------------------------------------------
 *  User route, authentication is required to access it
 * -----------------------------------------------------------------------------------
 */

Route::group([

    'middleware' => 'api',
    'prefix' => 'user'

], function ($router) {

    /*
        User operation routes
    */

});

/**
 * -----------------------------------------------------------------------------------
 *  Admin route, authentication and admin privileges are required to access it
 * -----------------------------------------------------------------------------------
 */

Route::group([

    'middleware' => 'api',
    'prefix' => 'admin'

], function ($router) {

    /*
        Admin management routes
    */
});

/**
 * -------------------------------------------------------------------------------
 *  Public routes, no authentication needed to access it
 * -------------------------------------------------------------------------------
 */
Route::group([

    'middleware' => 'api',
    'prefix' => 'public'

], function ($router) {

   /*
        Public restful endpoints
    */
});