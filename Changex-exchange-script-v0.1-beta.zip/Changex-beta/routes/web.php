<?php

/**
 *  This file is part of changex-exchange
 * ---------------------------------------------------------------
 *  (c) Soft Web <opensoftweb@gmail.com><support@opensoftweb.com>
 * ---------------------------------------------------------------
 *  URL <opensoftweb.com> for live demo
 * ---------------------------------------------------------------
 *  Built with Love
 */

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::any( '(.*)', function(){
    return view('index');
});

Route::fallback(function () {
    return view('index');
});
